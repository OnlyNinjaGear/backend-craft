# backend-craft fixtures

Small, runnable, **intentionally flawed** backend projects. They exist to:

1. forward-test the `backend-craft` skill (does an agent using the skill catch
   the planted failures without being told about them?)
2. regression-test the checker pack in `rules/semgrep/backend-craft.yml`
   (every mechanically detectable plant must be caught; clean contrast code
   must produce zero false positives)

Each fixture has its own README with the exact test command and a table of
planted failures mapped to `../FAILURE_CARDS.md` card ids. Plants are marked in
code with `PLANTED: <card-id>` comments.

| fixture | stack | test command | plants |
|---|---|---|---|
| `python-fastapi/` | FastAPI + stdlib sqlite3, uv | `uv run pytest -q` | 5 |
| `go-http/` | Go stdlib net/http, zero deps | `go vet ./... && go test ./...` | 5 |
| `ts-fastify/` | Fastify + TypeScript + vitest, pnpm | `pnpm install && pnpm test` | 5 |

Rules:

- Do not fix the planted flaws. The fixtures exist to be reviewed, not repaired.
- Happy-path tests must stay green; flaws are production-safety flaws, not
  compile errors.
- When forward-testing an agent against a fixture, do not let it read the
  fixture's README.md or the repo-root grading docs — they list the answers.
- Checker acceptance: run
  `uvx semgrep --config ../rules/semgrep/backend-craft.yml --no-git-ignore --exclude node_modules .`
  from this directory and compare hits against each README's table
  (see `../CHECKERS.md` for which cards are intentionally not Semgrep-covered).
